<?php
declare(strict_types=1);
$cfgFile=__DIR__.'/config.php';
if(!file_exists($cfgFile)){http_response_code(503);header('Content-Type: application/json; charset=utf-8');echo json_encode(['error'=>'not_installed','message'=>'Önce install.php çalıştırın.'],JSON_UNESCAPED_UNICODE);exit;}
$config=require $cfgFile; date_default_timezone_set($config['app']['timezone']??'Europe/Istanbul');
if(session_status()!==PHP_SESSION_ACTIVE){session_name($config['app']['session_name']??'ege_session');session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Lax','path'=>'/']);session_start();}
function db():PDO{static $p=null;global $config;if($p)return $p;$d=$config['db'];$p=new PDO("mysql:host={$d['host']};port={$d['port']};dbname={$d['name']};charset=utf8mb4",$d['user'],$d['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);return $p;}
function inp():array{$r=file_get_contents('php://input');$j=$r?json_decode($r,true):null;return is_array($j)?$j:($_POST?:[]);}function out($d,$s=200):never{http_response_code($s);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function user():?array{if(empty($_SESSION['uid']))return null;$q=db()->prepare("SELECT u.id,u.role_id,u.first_name,u.last_name,u.email,u.phone,u.institution,u.status,r.slug role,r.name role_name FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?");$q->execute([$_SESSION['uid']]);return $q->fetch()?:null;}
function need($role=null):array{$u=user();if(!$u||$u['status']!=='active')out(['error'=>'unauthorized'],401);if($role&&$u['role']!==$role)out(['error'=>'forbidden'],403);return $u;}
function certcode(){return 'EGE-'.date('Y').'-'.strtoupper(substr(bin2hex(random_bytes(6)),0,10));}
function activeTemplate(){return db()->query("SELECT * FROM certificate_templates WHERE is_active=1 ORDER BY id DESC LIMIT 1")->fetch()?:null;}
