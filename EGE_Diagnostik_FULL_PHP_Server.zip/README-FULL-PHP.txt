EGE DIAGNOSTIK FULL PHP SERVER
===============================
Bu paket GitHub'daki canlı tasarım dosyalarının tamamını korur ve PHP+MySQL backend ekler.

IIS: PHP 8.2/8.3 FastCGI + PDO MySQL + URL Rewrite Module gerekir.
1) ZIP'i IIS altındaki egediagnostik klasörüne çıkarın.
2) http://SUNUCU/egediagnostik/install.php açın.
3) MySQL bilgileri ve admin parolasını girin.
4) Kurulum sonrası install.php dosyasını silin.
5) Ana site: /egediagnostik/
6) Portal: /egediagnostik/login.html
7) Admin: /egediagnostik/admin.html
8) Sertifika: /egediagnostik/certificate-admin.html

Admin navbarında Sonuçlar altında Sertifika Tasarımı kalıcıdır.
